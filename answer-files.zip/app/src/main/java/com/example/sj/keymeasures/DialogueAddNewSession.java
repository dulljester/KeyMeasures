package com.example.sj.keymeasures;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

public class DialogueAddNewSession extends DialogFragment {
    private OnMyDialogResult myDialogResult;
    private AppDatabase db;
    private EditText editText;
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder= new AlertDialog.Builder(getActivity());
        LayoutInflater inflater= getActivity().getLayoutInflater();
        final View inf= inflater.inflate(R.layout.add_new_session_dialogue,null);
        db= AppDatabase.getInstance(getContext());
        editText= inf.findViewById(R.id.additionalHoursEditText);

        builder.setView(inf);
        builder.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if ( myDialogResult != null )
                    myDialogResult.finish(editText.getText().toString());
            }
        });
        //return super.onCreateDialog(savedInstanceState);
        return builder.create();
    }

    public void setDialogResult( OnMyDialogResult dialogResult ) {
        myDialogResult= dialogResult;
    }

    public interface OnMyDialogResult {
        void finish( String result ) ;
    }

}
