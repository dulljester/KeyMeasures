package com.example.sj.keymeasures;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

@Entity
public class KeyDirections {
    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name="activity_name")
    private String activityName;

    public int getId() {
        return id;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setId(int id) {
        this.id= id;
    }

    public void setActivityName( String activityName ) {
        this.activityName= activityName;
    }
}

